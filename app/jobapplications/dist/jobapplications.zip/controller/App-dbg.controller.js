sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("jobapplications.controller.App", {
      onInit() {
      }
  });
});